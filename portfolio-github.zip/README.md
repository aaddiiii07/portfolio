# Aditya Mulage — Portfolio

A personal portfolio website built with HTML, CSS, and vanilla JavaScript.

## 🌐 Live Site

Hosted via **GitHub Pages**:  
👉 `https://<your-username>.github.io/<repo-name>/`

> Replace `<your-username>` and `<repo-name>` with your actual GitHub username and repository name.

## ✨ Features

- Animated particle + hexagonal canvas background
- Custom gold cursor with ring trail
- Smooth scroll reveal animations
- Skill progress bars
- Achievements section with certificates
- Projects showcase
- Contact section
- Fully responsive

## 🚀 How to Deploy on GitHub Pages

1. Create a new repository on GitHub (e.g. `portfolio`)
2. Upload `index.html` and `README.md` to the repo
3. Go to **Settings → Pages**
4. Under **Source**, select `main` branch and `/ (root)`
5. Click **Save** — your site will be live in ~1 minute

## 🛠 Tech Stack

- HTML5
- CSS3 (custom properties, animations)
- Vanilla JavaScript (Canvas API, IntersectionObserver)
- Google Fonts (Space Grotesk, Syne)
